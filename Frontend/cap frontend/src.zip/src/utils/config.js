const config = {
    APP_NAME: 'Online Banking System',
    API_HOST: import.meta.env.VITE_API_HOST,
};

export default config;
