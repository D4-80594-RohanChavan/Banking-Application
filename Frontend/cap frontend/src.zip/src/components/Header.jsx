import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

function Header() {
    return (
        <header className="header">
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-3">
                        <img src="/src/assets/logo.jpg" alt="Krasv" width="150px" />
                    </div>
                    <nav className="col-9">
                        <ul className="nav justify-content-end">
                            <li className="nav-item">
                                <Link to="/" className="nav-link">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/about" className="nav-link">About</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/contact" className="nav-link">Contact</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/terms" className="nav-link">Terms of Conditions</Link>
                            </li>
                            <li classitem="nav-item">
                                <Link to="/privacy" className="nav-link">Privacy Policy</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/sign-in">
                                    <button className="btn btn-primary">Sign In</button>
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/sign-up">
                                    <button className="btn btn-primary">Sign Up</button>
                                </Link>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </header>
    );
}

export default Header;
