package com.axis.team2.technotribe.krasvbank.entity;

public enum UserRole {
	ROLE_CUSTOMER, ROLE_ADMIN, ROLE_USER
}
